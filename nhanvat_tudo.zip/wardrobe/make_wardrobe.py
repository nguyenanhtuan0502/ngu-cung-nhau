import sys,subprocess; sys.path.insert(0,'/home/claude/art')
from avatar_lib import *
OUT="/home/claude/art/wardrobe"
# ---- trang phục: nữ + nam
outfits=[
 ("ao_thun","Áo thun + quần short","tee",dict(tc="#ffffff",bc="#6fa8ff")),
 ("vay_hong","Váy xòe","dress",dict(tc="#ffd6e7",bc="#ff7a9c")),
 ("vay_xanh","Váy xanh","dress",dict(tc="#9fd8ff",bc="#3d7bd9")),
 ("ao_dai_do","Áo dài đỏ","aodai",dict(tc="#e8404f",bc="#ffffff")),
 ("ao_dai_trang","Áo dài trắng","aodai",dict(tc="#ffffff",bc="#ffffff")),
 ("do_the_thao","Đồ thể thao","sport",dict(tc="#ff7a3d",bc="#2b3a67")),
 ("do_ngu","Đồ ngủ","pajama",dict(tc="#b9a8ff",bc="#8d7cf0")),
 ("hoodie","Hoodie + quần dài","hoodie",dict(tc="#ff6b6b",bc="#3a3f5a")),
 ("dong_phuc","Đồng phục","uniform_g",dict(tc="#ffffff",bc="#3a4a8a")),
 ("ao_khoac","Áo khoác","jacket",dict(tc="#4fbf8f",bc="#555b6e")),
]
cells=[]; i=0
for fid,label,top,cols in outfits:
    for who,kw in (("nu",dict(skin="sang",hair="#7a4a30",hl="#a8704c",hs="bob",boy=False,shoe="#ff8fab",acc="")),("nam",dict(skin="vang",hair="#2b2b3a",hl="#5a5a78",hs="short",boy=True,shoe="#ffffff",acc=""))):
        t=top
        if who=="nam" and top=="dress": t="tee"
        if who=="nam" and top=="uniform_g": t="uniform_b"
        if who=="nam" and top=="aodai": t="aodai"
        p=avatar(top=t,**cols,**kw)
        open(f"{OUT}/{who}_{fid}.svg","w").write(svg("".join(p)))
        if who=="nu": cells.append((p,label,fid))
        else: cells[-1]=cells[-1]+(p,)
W=5*260; H=2*2*420+0
xs=""
for k,(p,label,fid,pm) in enumerate(cells):
    x=(k%5)*260; y=(k//5)*420
    # mỗi ô: nữ và nam cạnh nhau (thu nhỏ)
    inner=(f'<svg x="8" y="14" width="124" height="186" viewBox="0 0 400 600">{"".join(p)}</svg><svg x="124" y="14" width="124" height="186" viewBox="0 0 400 600">{"".join(pm)}</svg>')
    xs+=f'<g transform="translate({x},{y})"><rect x="6" y="6" width="248" height="214" rx="20" fill="#fff" stroke="#e5d9c8" stroke-width="3"/>{inner}<text x="130" y="206" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-size="17" font-weight="700" fill="#5a4636">{label}</text></g>'
Hh=2*226+10
sheet=f'<svg xmlns="http://www.w3.org/2000/svg" width="1300" height="{Hh}" viewBox="0 0 1300 {Hh}"><rect width="1300" height="{Hh}" fill="#eaf6ff"/>'+"".join(
  xs.replace(f'translate({(k%5)*260},{(k//5)*420})',f'translate({(k%5)*260},{(k//5)*226})') if False else "" for k in range(0))+'</svg>'
# dựng lại gọn
body=""
for k,(p,label,fid,pm) in enumerate(cells):
    x=(k%5)*260; y=(k//5)*228
    body+=f'<g transform="translate({x},{y})"><rect x="6" y="6" width="248" height="216" rx="20" fill="#fff" stroke="#e5d9c8" stroke-width="3"/><svg x="8" y="12" width="124" height="186" viewBox="0 0 400 600">{"".join(p)}</svg><svg x="128" y="12" width="124" height="186" viewBox="0 0 400 600">{"".join(pm)}</svg><text x="130" y="212" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-size="16" font-weight="700" fill="#5a4636">{label}</text></g>'
sheet=f'<svg xmlns="http://www.w3.org/2000/svg" width="1300" height="460" viewBox="0 0 1300 460"><rect width="1300" height="460" fill="#eaf6ff"/>{body}</svg>'
open("/home/claude/art/wardrobe_sheet.svg","w").write(sheet)
subprocess.run(["rsvg-convert","-w","1300","/home/claude/art/wardrobe_sheet.svg","-o","/home/claude/art/wardrobe_sheet.png"])
# ---- kiểu tóc (chỉ đầu)
hairs=[("bob","Bob",False),("long","Dài thẳng",False),("wavy","Dài gợn",False),("twin","Hai bím",False),("pony","Đuôi ngựa",False),("bun","Búi cao",False),("twinbun","Hai búi",False),("braid","Tết",False),("curly","Xoăn",False),
       ("short","Ngắn",True),("spiky","Nhọn",True),("side","Rẽ ngôi",True),("mushroom","Nấm",True),("mohawk","Mohican",True),("slick","Vuốt ngược",True),("curlyb","Xoăn ngắn",True)]
cols=["#7a4a30","#26263a","#e8b04a","#b04a4a"]
hb=""
for k,(hs,label,boy) in enumerate(hairs):
    p=avatar(hs=hs,boy=boy,hair=cols[k%4],hl="#ffffff",top="tee",tc="#fff",bc="#6fa8ff",skin=["sang","vang","ngam","nau"][k%4],acc="")
    open(f"{OUT}/hair_{hs}.svg","w").write(svg("".join(p)))
    x=(k%8)*190; y=(k//8)*220
    hb+=f'<g transform="translate({x},{y})"><rect x="6" y="6" width="178" height="208" rx="18" fill="#fff" stroke="#e5d9c8" stroke-width="3"/><svg x="14" y="10" width="162" height="162" viewBox="10 -10 380 380">{"".join(p)}</svg><text x="95" y="196" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-size="16" font-weight="700" fill="#5a4636">{label}</text></g>'
open("/home/claude/art/hair_sheet.svg","w").write(f'<svg xmlns="http://www.w3.org/2000/svg" width="1520" height="440" viewBox="0 0 1520 440"><rect width="1520" height="440" fill="#fff1d6"/>{hb}</svg>')
subprocess.run(["rsvg-convert","-w","1520","/home/claude/art/hair_sheet.svg","-o","/home/claude/art/hair_sheet.png"])
# ---- phụ kiện
accs=[("star","Kẹp sao"),("bow","Nơ"),("flower","Hoa cài"),("glasses","Kính"),("cap","Mũ lưỡi trai"),("headphone","Tai nghe"),("headband","Băng đô"),("catears","Tai mèo"),("beret","Mũ nồi"),("tophat","Mũ chóp"),("straw","Nón lá/cói"),("bucket","Mũ tai bèo"),("chef","Mũ đầu bếp"),("nightcap","Mũ ngủ"),("sleepmask","Bịt mắt ngủ"),("crown","Vương miện")]
ab=""
for k,(a,label) in enumerate(accs):
    p=avatar(hs="short" if a in("cap","tophat") else "bob",boy=False,acc=a,accc={"cap":"#ff6b6b","beret":"#e8404f","bucket":"#7fbf8f","catears":"#ffd7a0","headband":"#ff4f7b","nightcap":"#7b6cff"}.get(a,"#ffd54a"),hair="#5a3a2a",top="tee",tc="#fff",bc="#6fa8ff")
    open(f"{OUT}/acc_{a}.svg","w").write(svg("".join(p)))
    x=(k%8)*190; y=(k//8)*220
    ab+=f'<g transform="translate({x},{y})"><rect x="6" y="6" width="178" height="208" rx="18" fill="#fff" stroke="#e5d9c8" stroke-width="3"/><svg x="14" y="10" width="162" height="162" viewBox="0 -20 400 400">{"".join(p)}</svg><text x="95" y="196" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-size="16" font-weight="700" fill="#5a4636">{label}</text></g>'
open("/home/claude/art/acc_sheet.svg","w").write(f'<svg xmlns="http://www.w3.org/2000/svg" width="1520" height="440" viewBox="0 0 1520 440"><rect width="1520" height="440" fill="#eaf6ff"/>{ab}</svg>')
subprocess.run(["rsvg-convert","-w","1520","/home/claude/art/acc_sheet.svg","-o","/home/claude/art/acc_sheet.png"])
print("ok")
