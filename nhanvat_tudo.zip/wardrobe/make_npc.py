import sys,subprocess,json; sys.path.insert(0,'/home/claude/art')
from avatar_lib import *
OUT="/home/claude/art/npc"
N=[
 ("park_guide","Cô Mai","Hướng dẫn viên công viên",dict(skin="sang",hair="#7a4a30",hl="#a8704c",hs="pony",top="tee",tc="#7fd6a0",bc="#ffffff",shoe="#ffffff",acc="cap",accc="#7fd6a0"),"Công viên"),
 ("ice_cream","Chú Tư Kem","Bán kem",dict(skin="vang",hair="#3a2a2a",hl="#6a4a4a",hs="short",boy=True,top="apron",tc="#ffffff",bc="#ff9ad0",shoe="#ffffff",acc="chef"),"Công viên"),
 ("cinema_usher","Anh Vé","Nhân viên rạp phim",dict(skin="sang",hair="#2b2b3a",hl="#5a5a78",hs="slick",boy=True,top="suit",tc="#b3253c",bc="#2b2b3a",accc="#ffd54a",shoe="#2b2b3a"),"Rạp chiếu phim"),
 ("popcorn","Chị Bắp","Bán bắp rang",dict(skin="vang",hair="#e8b04a",hl="#f6d58a",hs="bun",top="apron",tc="#ff6b6b",bc="#ffffff",shoe="#ff6b6b",acc="bow"),"Rạp chiếu phim"),
 ("teacher_f","Cô Lan","Giáo viên",dict(skin="sang",hair="#26263a",hl="#5a5a78",hs="bun",top="aodai",tc="#ff9ac0",bc="#ffffff",shoe="#ffffff",acc="glasses"),"Phòng học"),
 ("teacher_m","Thầy Minh","Giáo viên",dict(skin="vang",hair="#3a2a2a",hl="#6a4a4a",hs="side",boy=True,top="suit",tc="#4a5a8a",bc="#2b2b3a",accc="#d94a4a",shoe="#2b2b3a",acc="glasses"),"Phòng học"),
 ("fisher","Bác Câu","Hồ câu cá",dict(skin="ngam",hair="#9a9aa8",hl="#d0d0dc",hs="short",boy=True,top="overalls",tc="#ffd54a",bc="#4a7bd9",shoe="#7a5a3a",acc="bucket,mustache",accc="#7fbf8f"),"Hồ câu cá"),
 ("shopper","Chị Shop","Khu mua sắm",dict(skin="sang",hair="#b04a4a",hl="#d98a8a",hs="wavy",top="dress",tc="#c58bff",bc="#ffd54a",shoe="#ffffff",acc="beret",accc="#ff6b8b"),"Khu mua sắm"),
 ("arcade","Anh Gấu","Khu vui chơi",dict(skin="nau",hair="#2a1c1c",hl="#5a3a3a",hs="curlyb",boy=True,top="hoodie",tc="#a8714d",bc="#6b4a3a",shoe="#ffffff",acc="catears",accc="#a8714d"),"Khu vui chơi"),
 ("baucua","Cô Bầu Cua","Quầy bầu cua",dict(skin="vang",hair="#26263a",hl="#5a5a78",hs="twinbun",top="aodai",tc="#e8404f",bc="#ffd54a",shoe="#ffd54a",acc="flower"),"Khu vui chơi"),
 ("broker_m","Ông Chứng","Khu chứng khoán",dict(skin="sang",hair="#5a5a6a",hl="#9a9aa8",hs="slick",boy=True,top="suit",tc="#2b2b3a",bc="#2b2b3a",accc="#3fbf8f",shoe="#2b2b3a",acc="tophat,mustache",),"Khu chứng khoán"),
 ("analyst","Cô Phân Tích","Khu chứng khoán",dict(skin="ngam",hair="#2a1c1c",hl="#5a3a3a",hs="pony",top="suit",tc="#3a4a8a",bc="#3a4a8a",accc="#ffd54a",shoe="#2b2b3a",acc="glasses"),"Khu chứng khoán"),
 ("cupid","Thần Tình Yêu","Khu hẹn hò",dict(skin="sang",hair="#ffd6e7",hl="#ffffff",hs="wavy",top="dress",tc="#ffffff",bc="#ff7a9c",shoe="#ff8fab",acc="wings,halo"),"Khu hẹn hò"),
 ("farmer","Bác Nông","Nông trại",dict(skin="ngam",hair="#7a4a30",hl="#a8704c",hs="short",boy=True,top="overalls",tc="#ff9a5a",bc="#3d7bd9",shoe="#7a5a3a",acc="straw"),"Nông trại"),
 ("dorm","Cô Ký Túc","Quản lý ký túc xá",dict(skin="vang",hair="#7a4a30",hl="#a8704c",hs="braid",top="pajama",tc="#ffb3c6",bc="#ff8fab",shoe="#ffffff",acc="nightcap",accc="#ffb3c6"),"Ký túc xá"),
 ("helper","Bé Mây","Trợ lý hướng dẫn",dict(skin="sang",hair="#7fd6ff",hl="#ffffff",hs="twinbun",top="hoodie",tc="#ffffff",bc="#7fd6ff",shoe="#7fd6ff",acc="catears,headphone",accc="#ffffff"),"Nhà riêng + Bản đồ"),
]
cells=[];meta=[]
for k,(fid,name,role,kw,area) in enumerate(N):
    p=avatar(**kw)
    open(f"{OUT}/npc_{fid}.svg","w").write(svg("".join(p)))
    open(f"{OUT}/npc_{fid}_anim.svg","w").write(svg(p[0]+'<g class="bob">'+"".join(p[1:])+'</g>',CSS))
    x=(k%8)*190; y=(k//8)*262
    cells.append(f'<g transform="translate({x},{y})"><rect x="6" y="6" width="178" height="250" rx="18" fill="#fff" stroke="#e5d9c8" stroke-width="3"/><svg x="14" y="10" width="162" height="190" viewBox="0 0 400 600">{"".join(p)}</svg><text x="95" y="216" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-size="16" font-weight="700" fill="#5a4636">{name}</text><text x="95" y="236" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-size="12" fill="#8a7461">{role}</text></g>')
    meta.append(dict(id=fid,name=name,role=role,area=area))
json.dump(meta,open(OUT+"/npc_list.json","w"),ensure_ascii=False,indent=1)
open("/home/claude/art/npc_sheet.svg","w").write(f'<svg xmlns="http://www.w3.org/2000/svg" width="1520" height="530" viewBox="0 0 1520 530"><rect width="1520" height="530" fill="#fff1d6"/>{"".join(cells)}</svg>')
subprocess.run(["rsvg-convert","-w","1520","/home/claude/art/npc_sheet.svg","-o","/home/claude/art/npc_sheet.png"])
