import os
OL="#6b4a3a"
def sw(w=4): return f'stroke="{OL}" stroke-width="{w}" stroke-linejoin="round" stroke-linecap="round"'
SK={"sang":("#ffe0c8","#f2b99b"),"vang":("#f6cfa6","#e0a97c"),"ngam":("#d9a073","#bf8156"),"nau":("#a8714d","#8c5836")}
GIRL_BASE=("bob","long","twin","pony","bun","twinbun","braid","wavy")
def hair_back(st,h):
    if st=="bob": return f'<path d="M56 222 Q52 62 200 58 Q348 62 344 222 L350 320 Q326 340 306 316 L94 316 Q74 340 50 320Z" fill="{h}" {sw()}/>'
    if st=="long": return f'<path d="M52 222 Q48 60 200 56 Q352 60 348 222 L362 440 Q330 470 300 440 L100 440 Q70 470 38 440Z" fill="{h}" {sw()}/>'
    if st=="wavy": return f'<path d="M52 222 Q48 60 200 56 Q352 60 348 222 Q372 300 350 350 Q372 392 336 404 L64 404 Q28 392 50 350 Q28 300 52 222Z" fill="{h}" {sw()}/>'
    if st=="twin": return (f'<ellipse cx="46" cy="300" rx="34" ry="62" fill="{h}" {sw()}/><ellipse cx="354" cy="300" rx="34" ry="62" fill="{h}" {sw()}/><path d="M62 220 Q60 66 200 62 Q340 66 338 220Z" fill="{h}" {sw()}/>')
    if st=="pony": return (f'<path d="M326 150 Q394 168 380 280 Q372 336 346 360 Q360 280 326 230Z" fill="{h}" {sw()}/><path d="M62 220 Q60 66 200 62 Q338 66 338 220Z" fill="{h}" {sw()}/>')
    if st=="bun": return (f'<circle cx="200" cy="54" r="40" fill="{h}" {sw()}/><path d="M62 220 Q60 66 200 62 Q340 66 338 220Z" fill="{h}" {sw()}/>')
    if st=="twinbun": return (f'<circle cx="62" cy="86" r="38" fill="{h}" {sw()}/><circle cx="338" cy="86" r="38" fill="{h}" {sw()}/><path d="M62 220 Q60 66 200 62 Q340 66 338 220Z" fill="{h}" {sw()}/>')
    if st=="braid":
        b="".join(f'<ellipse cx="{70-i*2}" cy="{300+i*36}" rx="24" ry="20" fill="{h}" {sw(3)}/>' for i in range(4))
        return b+f'<path d="M62 220 Q60 66 200 62 Q340 66 338 220Z" fill="{h}" {sw()}/><rect x="52" y="428" width="40" height="12" rx="6" fill="#ff7a9c" {sw(3)}/>'
    if st=="curly": return f'<g fill="{h}" {sw(3)}>'+"".join(f'<circle cx="{x}" cy="{y}" r="44"/>' for x,y in [(80,150),(120,92),(200,70),(280,92),(320,150),(74,230),(326,230)])+'</g>'
    return f'<path d="M64 222 Q62 66 200 62 Q338 66 336 222Z" fill="{h}" {sw()}/>'
def hair_front(st,h,hl):
    if st=="curly": st="curlyb"
    if st in GIRL_BASE:
        base=f'<path d="M66 214 Q70 78 200 74 Q330 78 334 214 Q316 170 286 150 Q262 190 232 156 Q214 196 190 154 Q166 192 142 152 Q104 166 66 214Z" fill="{h}" {sw()}/>'
        return base+f'<path d="M120 112 Q160 88 214 96" fill="none" stroke="{hl}" stroke-width="9" stroke-linecap="round" opacity=".8"/>'
    if st=="short": return (f'<path d="M66 214 Q64 80 200 76 Q336 80 334 214 Q322 160 296 142 Q250 172 200 140 Q150 168 104 146 Q76 168 66 214Z" fill="{h}" {sw()}/><path d="M126 108 Q170 90 220 98" fill="none" stroke="{hl}" stroke-width="9" stroke-linecap="round" opacity=".8"/>')
    if st=="spiky": return f'<path d="M62 214 Q58 120 84 98 L92 56 L130 88 L160 36 L192 84 L232 30 L250 86 L296 50 L306 100 L334 96 Q344 130 338 214 Q322 160 296 142 Q250 172 200 140 Q150 168 104 146 Q76 168 62 214Z" fill="{h}" {sw()}/>'
    if st=="curlyb": return f'<g fill="{h}" {sw(3)}>'+"".join(f'<circle cx="{x}" cy="{y}" r="{r}"/>' for x,y,r in [(96,150,36),(140,112,40),(200,100,42),(260,112,40),(306,150,36)])+'</g>'
    if st=="side": return (f'<path d="M62 214 Q60 80 200 74 Q340 80 338 214 Q326 150 280 138 Q190 170 90 150 Q70 170 62 214Z" fill="{h}" {sw()}/><path d="M96 120 Q150 92 250 104" fill="none" stroke="{hl}" stroke-width="9" stroke-linecap="round" opacity=".8"/>')
    if st=="mushroom": return (f'<path d="M58 220 Q52 70 200 66 Q348 70 342 220 L330 168 Q200 134 70 168Z" fill="{h}" {sw()}/><path d="M110 108 Q160 86 220 94" fill="none" stroke="{hl}" stroke-width="9" stroke-linecap="round" opacity=".8"/>')
    if st=="mohawk": return (f'<path d="M150 130 Q150 30 200 14 Q250 30 250 130 Q226 112 200 112 Q174 112 150 130Z" fill="{h}" {sw()}/><path d="M70 190 Q74 120 120 108 Q96 150 90 196Z M330 190 Q326 120 280 108 Q304 150 310 196Z" fill="{h}" {sw(3)}/>')
    if st=="slick": return (f'<path d="M66 214 Q58 84 200 70 Q342 84 334 214 Q322 140 270 118 Q200 108 130 118 Q78 140 66 214Z" fill="{h}" {sw()}/><path d="M150 104 Q190 20 270 66 Q230 70 220 104Z" fill="{h}" {sw()}/><path d="M130 112 Q190 96 250 108" fill="none" stroke="{hl}" stroke-width="8" stroke-linecap="round" opacity=".8"/>')
def eye(cx,boy):
    br=7 if boy else 5
    return (f'<g class="eye"><ellipse cx="{cx}" cy="238" rx="25" ry="32" fill="#3a2a2a" {sw(3)}/><ellipse cx="{cx}" cy="244" rx="19" ry="22" fill="#8a5a38"/><ellipse cx="{cx}" cy="248" rx="10" ry="12" fill="#2a1c1c"/><circle cx="{cx-8}" cy="226" r="9" fill="#fff"/><circle cx="{cx+9}" cy="252" r="4.5" fill="#fff"/><path d="M{cx-26} 220 Q{cx} 202 {cx+26} 220" fill="none" stroke="{OL}" stroke-width="{br}" stroke-linecap="round"/></g>')

LS={"hoodie","uniform_b","jacket","aodai","pajama","suit","labcoat"}
PANTS={"hoodie","uniform_b","jacket","pajama","suit","labcoat","aodai","overalls"}
def avatar(skin="sang",hair="#7a4a30",hl="#a8704c",hs="bob",boy=False,top="tee",tc="#ffffff",bc="#6fa8ff",shoe="#ff8fab",acc="",accc="#ffd54a"):
    S,SD=SK[skin]; accs=[a for a in (acc or "").split(",") if a]
    p=['<ellipse cx="200" cy="562" rx="95" ry="16" fill="#000" opacity="0.16"/>']
    if "wings" in accs:
        p.append('<g fill="#fff" '+sw(3)+'><path d="M150 350 Q40 250 20 330 Q10 400 120 410Z"/><path d="M250 350 Q360 250 380 330 Q390 400 280 410Z"/></g>')
    p.append(hair_back(hs,hair))
    p.append(f'<rect x="166" y="440" width="30" height="86" rx="13" fill="{S}" {sw()}/><rect x="204" y="440" width="30" height="86" rx="13" fill="{S}" {sw()}/>')
    p.append(f'<rect x="164" y="496" width="34" height="34" rx="10" fill="#fff" {sw()}/><rect x="202" y="496" width="34" height="34" rx="10" fill="#fff" {sw()}/>')
    p.append(f'<path d="M146 546 Q146 522 172 522 L196 522 Q204 538 196 552 L152 552 Q146 552 146 546Z" fill="{shoe}" {sw()}/><path d="M254 546 Q254 522 228 522 L204 522 Q196 538 204 552 L248 552 Q254 552 254 546Z" fill="{shoe}" {sw()}/>')
    # dưới
    if top=="uniform_g":
        p.append(f'<path d="M150 424 Q200 438 250 424 L276 492 Q200 506 124 492Z" fill="{bc}" {sw()}/><path d="M176 432 L162 498 M200 436 L200 502 M224 432 L238 498" stroke="{OL}" stroke-width="2.5" opacity=".5" fill="none"/>')
    elif top=="aodai":
        p.append(f'<path d="M154 424 Q200 438 246 424 L254 524 Q226 532 202 524 L198 524 Q174 532 146 524Z" fill="{bc}" {sw()}/><path d="M200 438 L200 522" stroke="{OL}" stroke-width="3" opacity=".6"/>')
    elif top in PANTS:
        p.append(f'<path d="M154 424 Q200 438 246 424 L252 506 Q226 516 202 506 L198 506 Q174 516 148 506Z" fill="{bc}" {sw()}/><path d="M200 438 L200 504" stroke="{OL}" stroke-width="3" opacity=".6"/>')
        if top=="pajama":
            p.append('<g fill="#fff" opacity=".75">'+"".join(f'<circle cx="{x}" cy="{y}" r="5"/>' for x,y in [(172,452),(226,456),(180,486),(222,490),(166,470),(236,474)])+'</g>')
    else:
        p.append(f'<path d="M154 424 Q200 438 246 424 L250 472 Q226 484 202 472 L198 472 Q174 484 150 472Z" fill="{bc}" {sw()}/><path d="M200 436 L200 470" stroke="{OL}" stroke-width="3" opacity=".6"/>')
        if top=="sport": p.append(f'<path d="M156 428 L152 470 M244 428 L248 470" stroke="#fff" stroke-width="6" stroke-linecap="round"/>')
    sl = tc if top in LS else S
    arm=lambda d,c,w:f'<path d="{d}" fill="none" stroke="{c}" stroke-width="{w}" stroke-linecap="round"/>'
    L="M160 350 Q130 382 126 418"; R="M240 350 Q270 382 274 418"
    hand=lambda x:(f'<circle cx="{x}" cy="420" r="11" fill="{S}" {sw(3)}/>' if sl!=S else '')
    p.append('<g class="arm-l">'+arm(L,OL,26)+arm(L,sl,19)+hand(126)+'</g>')
    p.append('<g class="arm-r">'+arm(R,OL,26)+arm(R,sl,19)+hand(274)+'</g>')
    sleeves=f'<path d="M150 340 Q128 352 132 376 L158 372 L160 344Z" fill="{tc}" {sw()}/><path d="M250 340 Q272 352 268 376 L242 372 L240 344Z" fill="{tc}" {sw()}/>'
    collar=f'<path d="M184 332 Q200 346 216 332" fill="none" stroke="{OL}" stroke-width="3.5" stroke-linecap="round"/>'
    if top=="dress":
        p.append(f'<path d="M156 336 Q200 322 244 336 L252 400 L292 500 Q200 522 108 500 L148 400Z" fill="{tc}" {sw()}/><path d="M148 400 Q200 416 252 400" fill="none" stroke="{bc}" stroke-width="10"/><path d="M148 400 Q200 416 252 400" fill="none" stroke="{OL}" stroke-width="3"/><circle cx="200" cy="440" r="9" fill="{bc}" {sw(3)}/>')
    elif top=="aodai":
        p.append(f'<path d="M156 336 Q200 322 244 336 L254 420 L270 524 Q200 540 130 524 L146 420Z" fill="{tc}" {sw()}/>'
          f'<path d="M200 346 L200 530" stroke="{OL}" stroke-width="3" opacity=".5"/><path d="M147 420 Q150 470 152 520 M253 420 Q250 470 248 520" stroke="{OL}" stroke-width="2.5" fill="none" opacity=".45"/>'
          f'<rect x="184" y="326" width="32" height="16" rx="6" fill="{tc}" {sw(3)}/><circle cx="210" cy="352" r="3.5" fill="{bc}"/><circle cx="226" cy="392" r="3.5" fill="{bc}"/>'
          f'<g fill="{bc}" opacity=".85">'+"".join(f'<circle cx="{x}" cy="{y}" r="7"/><circle cx="{x}" cy="{y}" r="3" fill="#fff"/>' for x,y in [(172,430),(176,480),(226,456),(224,506)])+'</g>')
    else:
        p.append(f'<path d="M156 336 Q200 322 244 336 L252 432 Q200 446 148 432Z" fill="{tc}" {sw()}/>')
        if top in("tee","tank","sport","apron","overalls"): p.append(sleeves)
        if top=="tee": p.append(f'<path d="M200 392 C190 380 176 388 186 400 L200 414 L214 400 C224 388 210 380 200 392Z" fill="{bc if boy else "#ff7a9c"}" {sw(3)}/>')
        if top=="sport": p.append(f'<path d="M168 340 L164 430 M232 340 L236 430" stroke="{bc}" stroke-width="8" stroke-linecap="round"/><text x="200" y="402" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-weight="900" font-size="38" fill="{bc}" stroke="{OL}" stroke-width="1.5">10</text>')
        if top=="hoodie": p.append(f'<path d="M168 410 L232 410 L240 438 L160 438Z" fill="none" {sw(3)}/><path d="M188 346 L186 376 M212 346 L214 376" stroke="#fff" stroke-width="3" stroke-linecap="round"/>')
        if top in("uniform_b","uniform_g"): p.append(f'<path d="M182 332 L200 356 L218 332Z" fill="#fff" {sw(3)}/><path d="M200 354 L190 372 L200 420 L210 372Z" fill="{"#d94a4a" if top=="uniform_b" else "#ff7a9c"}" {sw(3)}/>')
        if top=="jacket": p.append(f'<path d="M200 332 L200 436" stroke="{OL}" stroke-width="3.5"/><path d="M182 332 L200 352 L218 332" fill="{S}" stroke="{OL}" stroke-width="3"/>')
        if top=="pajama": p.append(f'<path d="M184 332 L200 350 L216 332" fill="none" {sw(3)}/><g fill="#fff" opacity=".8">'+"".join(f'<circle cx="{x}" cy="{y}" r="5"/>' for x,y in [(174,368),(226,372),(184,404),(218,410),(200,384),(166,414),(236,420)])+'</g><circle cx="200" cy="372" r="3" fill="#fff"/><circle cx="200" cy="400" r="3" fill="#fff"/>')
        if top=="apron": p.append(f'<path d="M184 338 L176 346 L166 438 L234 438 L224 346 L216 338Z" fill="{bc}" {sw()}/><rect x="182" y="392" width="36" height="28" rx="6" fill="none" {sw(3)}/>')
        if top=="suit": p.append(f'<path d="M156 336 L186 334 L198 396 L186 438 Q165 440 148 432Z" fill="{tc}" {sw()}/><path d="M244 336 L214 334 L202 396 L214 438 Q235 440 252 432Z" fill="{tc}" {sw()}/><path d="M186 334 L200 352 L214 334Z" fill="#fff" {sw(3)}/><path d="M200 352 L192 368 L200 412 L208 368Z" fill="{accc}" {sw(3)}/>')
        if top=="overalls": p.append(f'<path d="M172 380 L228 380 L232 440 L168 440Z" fill="{bc}" {sw()}/><path d="M176 380 L180 338 M224 380 L220 338" stroke="{bc}" stroke-width="9" stroke-linecap="round"/><circle cx="178" cy="384" r="5" fill="#ffd54a" {sw(2)}/><circle cx="222" cy="384" r="5" fill="#ffd54a" {sw(2)}/>')
        if top=="labcoat": p.append(f'<path d="M152 336 Q200 322 248 336 L260 482 Q200 496 140 482Z" fill="#fff" {sw()}/><path d="M200 340 L200 488" stroke="{OL}" stroke-width="3"/><path d="M184 334 L200 372 L216 334Z" fill="{tc}" {sw(3)}/><rect x="212" y="420" width="30" height="26" rx="5" fill="none" {sw(3)}/><circle cx="226" cy="392" r="6" fill="{accc}" {sw(2)}/>')
        p.append(collar)
    p.append(f'<rect x="184" y="312" width="32" height="30" rx="10" fill="{SD}" {sw()}/><ellipse cx="70" cy="228" rx="15" ry="19" fill="{S}" {sw()}/><ellipse cx="330" cy="228" rx="15" ry="19" fill="{S}" {sw()}/>')
    p.append(f'<ellipse cx="200" cy="215" rx="130" ry="114" fill="{S}" {sw()}/>')
    ba=.35 if boy else .55
    face=eye(146,boy)+eye(254,boy)+f'<ellipse cx="108" cy="276" rx="21" ry="12" fill="#ff8fa3" opacity="{ba}"/><ellipse cx="292" cy="276" rx="21" ry="12" fill="#ff8fa3" opacity="{ba}"/><path d="M200 262 Q203 267 198 268" fill="none" stroke="{OL}" stroke-width="3" stroke-linecap="round" opacity=".7"/>'
    face+= (f'<path d="M180 280 Q200 306 220 280Z" fill="#8a2f3f" {sw(3)}/><path d="M188 290 Q200 298 212 290" fill="#ff8fa3"/>' if boy else f'<path d="M184 280 Q200 298 216 280 Q200 284 184 280Z" fill="#e8627c" {sw(3)}/>')
    face+=f'<path d="M126 196 Q146 186 166 194 M234 194 Q254 186 274 196" fill="none" stroke="{hair}" stroke-width="{8 if boy else 6}" stroke-linecap="round"/>'
    if "mustache" in accs: face+=f'<path d="M156 272 Q178 262 200 272 Q222 262 244 272 Q222 286 200 276 Q178 286 156 272Z" fill="{hair}" {sw(3)}/>'
    p.append(face)
    p.append(hair_front(hs,hair,hl))
    A={
     "star":f'<path d="M286 120 l7 16 17 2 -13 11 4 17 -15 -9 -15 9 4 -17 -13 -11 17 -2z" fill="#ffd54a" {sw(3)}/>',
     "bow":f'<g transform="translate(290,118)"><path d="M0 0 L-34 -20 L-34 22Z M0 0 L34 -20 L34 22Z" fill="#ff7a9c" {sw(3)}/><circle r="9" fill="#ff4f7b" {sw(3)}/></g>',
     "flower":f'<g transform="translate(110,122)">'+"".join(f'<circle cx="{dx}" cy="{dy}" r="13" fill="#ffadc6" {sw(3)}/>' for dx,dy in [(0,-16),(15,-5),(9,13),(-9,13),(-15,-5)])+f'<circle r="9" fill="#ffd54a" {sw(3)}/></g>',
     "glasses":f'<g fill="#fff" fill-opacity=".25" {sw(5)}><circle cx="146" cy="240" r="40"/><circle cx="254" cy="240" r="40"/></g><path d="M186 240 L214 240" {sw(5)}/>',
     "cap":f'<path d="M64 170 Q70 66 200 62 Q330 66 336 170 Q200 140 64 170Z" fill="{accc}" {sw()}/><path d="M60 170 Q200 148 340 170 Q372 176 366 190 Q200 166 64 196Z" fill="{bc}" {sw()}/>',
     "headphone":f'<path d="M62 230 Q56 70 200 66 Q344 70 338 230" fill="none" stroke="#3b3f58" stroke-width="12" stroke-linecap="round"/><rect x="42" y="206" width="30" height="52" rx="12" fill="#ff6b8b" {sw(3)}/><rect x="328" y="206" width="30" height="52" rx="12" fill="#ff6b8b" {sw(3)}/>',
     "chef":f'<g fill="#fff" {sw(4)}><circle cx="138" cy="70" r="36"/><circle cx="262" cy="70" r="36"/><circle cx="200" cy="52" r="42"/><rect x="118" y="82" width="164" height="50" rx="10"/></g><path d="M118 112 L282 112" stroke="{OL}" stroke-width="3"/>',
     "straw":f'<ellipse cx="200" cy="130" rx="200" ry="38" fill="#f2d27a" {sw()}/><path d="M92 128 Q96 44 200 40 Q304 44 308 128 Q200 150 92 128Z" fill="#f6e08e" {sw()}/><path d="M94 116 Q200 140 306 116" fill="none" stroke="{accc}" stroke-width="12"/>',
     "bucket":f'<path d="M78 150 Q84 58 200 54 Q316 58 322 150Z" fill="{accc}" {sw()}/><ellipse cx="200" cy="152" rx="170" ry="26" fill="{accc}" {sw()}/><path d="M80 142 Q200 168 320 142" fill="none" stroke="{bc}" stroke-width="10"/>',
     "catears":f'<g {sw(4)}><path d="M80 120 L96 28 L168 84Z" fill="{accc}"/><path d="M320 120 L304 28 L232 84Z" fill="{accc}"/></g><path d="M98 98 L104 54 L138 82Z M302 98 L296 54 L262 82Z" fill="#ffb3c6"/>',
     "tophat":f'<ellipse cx="200" cy="108" rx="140" ry="24" fill="#2b2b3a" {sw()}/><rect x="124" y="12" width="152" height="98" rx="14" fill="#2b2b3a" {sw()}/><rect x="124" y="82" width="152" height="18" fill="{accc}" stroke="{OL}" stroke-width="3"/>',
     "headband":f'<path d="M70 168 Q200 128 330 168" fill="none" stroke="{accc}" stroke-width="20" stroke-linecap="round"/><path d="M70 168 Q200 128 330 168" fill="none" stroke="{OL}" stroke-width="2" opacity=".4"/>',
     "nightcap":f'<path d="M62 172 Q66 70 190 60 Q300 56 350 130 L376 236 Q310 176 270 154 Q150 140 62 172Z" fill="{accc}" {sw()}/><circle cx="378" cy="244" r="19" fill="#fff" {sw(3)}/><g fill="#fff" opacity=".8">'+"".join(f'<circle cx="{x}" cy="{y}" r="6"/>' for x,y in [(130,110),(190,88),(250,100),(300,128)])+'</g>',
     "sleepmask":f'<rect x="112" y="112" width="176" height="46" rx="22" fill="#7b6cff" {sw(4)}/><path d="M142 134 Q160 124 178 134 M222 134 Q240 124 258 134" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round"/>',
     "beret":f'<path d="M72 148 Q70 66 190 56 Q310 54 322 128 Q250 100 72 148Z" fill="{accc}" {sw()}/><circle cx="200" cy="48" r="9" fill="{accc}" {sw(3)}/>',
     "crown":f'<path d="M110 120 L120 52 L160 92 L200 36 L240 92 L280 52 L290 120Z" fill="#ffd54a" {sw()}/><circle cx="200" cy="64" r="7" fill="#ff6b8b"/><circle cx="130" cy="72" r="5" fill="#6fd0ff"/><circle cx="270" cy="72" r="5" fill="#6fd0ff"/>',
     "halo":f'<ellipse cx="200" cy="40" rx="70" ry="16" fill="none" stroke="#ffd54a" stroke-width="10"/>',
    }
    for a in accs:
        if a in A: p.append(A[a])
    return p

CSS="""<style>.eye{transform-box:fill-box;transform-origin:center;animation:b 4s infinite}@keyframes b{0%,92%,100%{transform:scaleY(1)}95%{transform:scaleY(.08)}}
.bob{animation:bob 1.6s ease-in-out infinite}@keyframes bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-7px)}}
.arm-l{transform-origin:160px 350px;animation:al 1.6s ease-in-out infinite}.arm-r{transform-origin:240px 350px;animation:ar 1.6s ease-in-out infinite}
@keyframes al{0%,100%{transform:rotate(3deg)}50%{transform:rotate(-5deg)}}@keyframes ar{0%,100%{transform:rotate(-3deg)}50%{transform:rotate(5deg)}}</style>"""
def svg(body,css="",vb="0 0 400 600",w=400,h=600): return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vb}" width="{w}" height="{h}">{css}{body}</svg>'
def cell(p,x,y,label,w=248,h=408,vb="0 0 400 600",iw=228,ih=342,sub=""):
    return (f'<g transform="translate({x},{y})"><rect x="6" y="6" width="{w}" height="{h}" rx="22" fill="#fff" stroke="#e5d9c8" stroke-width="3"/>'
      f'<svg x="{(w+12-iw)/2}" y="14" width="{iw}" height="{ih}" viewBox="{vb}">{"".join(p)}</svg>'
      f'<text x="{w/2+6}" y="{ih+36}" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-size="19" font-weight="700" fill="#5a4636">{label}</text>'
      f'<text x="{w/2+6}" y="{ih+60}" text-anchor="middle" font-family="DejaVu Sans, sans-serif" font-size="14" fill="#8a7461">{sub}</text></g>')
